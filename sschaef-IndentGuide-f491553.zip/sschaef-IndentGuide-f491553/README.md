## Indent Guide plug-in for Eclipse

Warning: This repo is not actively maintained. Please fork and fix bugs by yourself if you find one.

### Feature
This plug-in adds 'Indent Guide' (vertical line on indentation columns) to eclipse text editor.

### Update Site
https://sschaef.github.io/IndentGuide/update

### Web page
https://sschaef.github.io/IndentGuide

### Copyright
Please note that this repository is a fork from http://github.com/atlanto/IndentGuide, which doesn't exist anymore. I reuploaded the contents in order to make it available to others. Furthermore I licensed it with the MIT License.
