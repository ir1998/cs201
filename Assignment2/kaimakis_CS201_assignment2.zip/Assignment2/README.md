Nick Kaimakis
CS201 - Miller - MW 830am
Assignment 2 - GUI for Cinemate

Everything works! All parts of assingment on scoring have been completed